import './App.css';
import CodeEdit from './components/CodeEdit';

function App() {
  return(
    <>
    <CodeEdit/>
    </>
  )
}

export default App;